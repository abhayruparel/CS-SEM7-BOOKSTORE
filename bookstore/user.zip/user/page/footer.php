

<html>
<body>
        <footer class="footer text-center"></footer>
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="assets/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>
    <!--Nice scroll JavaScript -->
    <script src="js/jquery.nicescroll.js"></script>
    <!-- ============================================================== -->
    <!-- This page plugins -->
    <!-- ============================================================== -->
    <!-- chartist chart -->
    <script src="assets/bower_components/chartist-js/dist/chartist.min.js"></script>
    <script src="assets/bower_components/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="assets/bower_components/jquery-sparkline/jquery.sparkline.min.js"></script>
    <script src="assets/bower_components/jquery-sparkline/jquery.charts-sparkline.js"></script>
    <script src="assets/bower_components/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="assets/bower_components/vectormap/jquery-jvectormap-world-mill-en.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/myadmin.js"></script>
    <script src="js/dashboard1.js"></script>
</body>


<!-- Mirrored from wrappixel.com/demos/admin-templates/maple-admin/main/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 05 Jan 2019 04:48:09 GMT -->
</html>
